<?php $__env->startSection('content'); ?>
    <section class="relative bg-contain bg-no-repeat home-hero" id="intro">
        <img
                src="<?php echo e(asset('images/1.svg')); ?>"
                alt="a girl with a computer"
                class="home-hero-bg <?php if(app()->getLocale () === 'en'): ?> en-home-hero-bg <?php endif; ?>"
        >

        <div class="px-8 md:px-24 pt-8 md:pb-0">
            <?php echo $__env->make('partials.nav-home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <?php echo $__env->make('hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </section>


    <?php echo $__env->make('home-services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

    <?php echo $__env->make('contact-ways', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('request-steps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('testimonial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <?php echo $__env->make('team', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        const scrollAnimation = window.sal();

        scrollAnimation.enable();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/laravel/projects/redpencilit/resources/views/welcome.blade.php ENDPATH**/ ?>