<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'RedPencilIt')); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('css/line-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <style>
        <?php if(app()->getLocale() === 'fa'): ?>
        body {
            text-align: right;
            direction: rtl;
            font-family: Sahel;
        }

        <?php else: ?>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol";
            direction: ltr;
            text-align: left;
        }
        <?php endif; ?>
    </style>


    <script>
        window.Redpencilit = <?php echo json_encode([
                'signed' => Auth::check(),
                'user' => Auth::user(),
                'locale' => app()->getLocale()
            ]);; ?>;
        window.default_locale = "<?php echo e(config('app.locale')); ?>";
        window.fallback_locale = "<?php echo e(config('app.fallback_locale')); ?>";
        window.messages = <?php echo json_encode($messages, 15, 512) ?>;
    </script>
</head>
<body class="<?php if(app()->getLocale() === 'fa'): ?> fa <?php else: ?> en <?php endif; ?>">
<div id="app" class="overflow-hidden">
    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>

<?php /**PATH /Users/laravel/projects/redpencilit/resources/views/layouts/home.blade.php ENDPATH**/ ?>