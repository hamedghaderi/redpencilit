{{-- <script>
  let inputs = document.getElementsByTagName('input');

  Array.from(inputs).forEach(input => {
    input.addEventListener('keyup', function(e) {
      let parent = this.parentNode;
      let feedback = parent.nextElementSibling;

      if ( feedback !== null && feedback.classList.contains('feedback') ) {
        feedback.parentElement.removeChild(feedback);
      }
    });
  });
</script> --}}