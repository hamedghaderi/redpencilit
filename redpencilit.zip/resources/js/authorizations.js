let user = window.Redpencilit.user;

module.exports = {
   hasRole(roles) {

   }
};