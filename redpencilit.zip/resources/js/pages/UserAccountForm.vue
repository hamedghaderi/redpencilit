<template>

</template>

<script>
    export default {
        props: ['name', 'email', 'phone', 'username'],
    }
</script>