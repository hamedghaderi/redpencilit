<?php

namespace App\Redpencilit;

class Gender
{
    const MALE = 1;
    const FEMALE = 0;
}