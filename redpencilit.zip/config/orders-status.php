<?php

return [
    'unfulfilled' => 1,
    'pending' => 2,
    'fulfilled' => 3
];
